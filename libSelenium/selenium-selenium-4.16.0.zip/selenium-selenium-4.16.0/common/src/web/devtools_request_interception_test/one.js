function printScriptName() {
  document.getElementById('result').innerHTML = 'one';
}
